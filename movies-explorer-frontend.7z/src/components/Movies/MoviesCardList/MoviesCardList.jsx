import React from "react";
import "./MoviesCardList.css";
import MoviesCard from "../MoviesCard/MoviesCard";
import Preloader from "../../Preloader/Preloader";

function MoviesCardList({
  movies,
  isLoading,
  errorSearch,
  saveMovies,
  setSaveMovies,
}) {
  // // Функция сравнивает id сохранённого фильма с id фильма на странице
  // function compareFilm(saveMovies, movie) {
  //   return saveMovies.find((item) => item.movieId === movie.id);
  // }

  const moviesElements = movies.map((movie, index) => (
    <MoviesCard
      key={`${movie.id}_${index}`}
      movie={movie}
      saveMovies={saveMovies}
      setSaveMovies={setSaveMovies}
    />
  ));

  return (
    <section className="movies">
      <span className="movies__error">{errorSearch}</span>
      {isLoading ? <Preloader /> : <ul className="movie">{moviesElements}</ul>}
    </section>
  );
}

export default MoviesCardList;
