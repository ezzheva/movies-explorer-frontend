import React, { useEffect, useState } from "react";
import "./MoviesCard.css";
//import Movie from "../../image/movie.svg";
import { useLocation } from "react-router-dom";
// import { MOVIES_URL } from "../../../utils/MoviesApi";
import * as MainApi from "../../../utils/MainApi";
import * as MoviesApi from "../../../utils/MoviesApi";

function MoviesCard({ movie, saveMovies, setSaveMovies }) {
  const srcImg = movie.image.url
    ? `https://api.nomoreparties.co/${movie.image.url}`
    : movie.image;
  const [saveBtn, setSaveBtn] = useState(movie.isSaved);
  const location = useLocation();
  const [isDeleted, setIsDeleted] = useState(false);
  // const [saveMovies, setSaveMovies] = useState([]); //сохраненные фильмы

  // function handleSave() {
  //   handleSaveMovie(movie);
  //   handleClick();
  // }

  function handleClick() {
    // setSaveBtn(saveBtn);
    if (saveBtn) {
      setSaveBtn(false);
      handleDelete(movie._id);
    } else {
      handleSaveMovie(movie);
      setSaveBtn(true);
    }
    // if (!saveBtn) {
    //   setSaveBtn =
    //     saveMovies.some((item) => item.movieId === movie.id) || movie._id;
    // }
  }

  function handleSaveMovie(movie) {
    setSaveBtn(true);
    return MainApi.addSavedMovies({
      country: movie.country,
      director: movie.director,
      duration: movie.duration,
      year: movie.year,
      description: movie.description,
      image: `https://api.nomoreparties.co/${movie.image.url}`,
      trailerLink: movie.trailerLink,
      thumbnail: `https://api.nomoreparties.co${movie.image.formats.thumbnail.url}`,
      movieId: movie.id,
      nameRU: movie.nameRU,
      nameEN: movie.nameEN,
    })
      .then((movie) => {
        setSaveBtn(true);
        setSaveMovies([movie, ...saveMovies]);
        localStorage.setItem(
          "savedMovies",
          JSON.stringify([movie, ...saveMovies])
        );
      })
      .catch((err) => {
        setSaveBtn(true);
        console.error(err);
      });
  }

  function handleDelete() {
    handleDeleteMovie(movie._id);
    handleClick();
  }

  function handleDeleteMovie(movieId) {
    MainApi.deleteMovie(movieId)
      .then(() => {
        setIsDeleted(true);
        setSaveMovies((movie) => movie.filter((m) => m._id !== movieId));
        localStorage.setItem(
          "savedMovies",
          JSON.stringify(saveMovies.filter((item) => item._id !== movieId))
        );
      })
      .catch((err) => {
        console.error(err);
      });
  }

  const formatDuration = (duration) => {
    const hours = Math.floor(duration / 60);
    const minutes = duration % 60;
    return `${hours > 0 ? hours + "ч " : "0ч "}${
      minutes > 0 ? minutes + "м" : "0м"
    }`;
  };
  if (isDeleted) {
    return null;
  }
  return (
    <li className="movie__blok">
      <a href={movie.trailerLink} terget="_blank" rel="noreferrer">
        <img className="movie__img" src={srcImg} alt={movie.nameRU} />
      </a>
      <div className="movie__box">
        <div className="movie__container">
          <h2 className="movie__title">{movie.nameRU}</h2>
          {/* {saveBtn ? <button
            type="button"
            className={`movie__like ${saveBtn ? "movie__like_active" : ""} ${
              location.pathname === "/saved-movies" ? "movie__del" : ""
            }`}
            aria-label="Сохранить фильм в избранное" } */}
          <button
            type="button"
            className={`movie__like ${saveBtn ? "movie__like_active" : ""} ${
              location.pathname === "/saved-movies" ? "movie__del" : ""
            }`}
            aria-label="Сохранить фильм в избранное"
            onClick={
              handleClick
              // location.pathname !== "/saved-movies" || saveBtn
              //   ? handleSave
              //   : handleDelete
            }
          ></button>
        </div>
        <p className="movie__time">{formatDuration(movie.duration)}</p>
      </div>
    </li>
  );
}

export default MoviesCard;
