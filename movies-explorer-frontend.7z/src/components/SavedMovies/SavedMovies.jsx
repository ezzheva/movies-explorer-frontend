import Header from "../Header/Header";
import SearchForm from "../Movies/SearchForm/SearchForm";
import Footer from "../Footer/Footer";
import MoviesCardList from "../Movies/MoviesCardList/MoviesCardList";
//import { useState } from "react";
import * as MainApi from "../../utils/MainApi";
import { useEffect, useState } from "react";
//import { filterWordMovies, filterShortMovies } from "../../utils/filterMovies";

function SavedMovies({ loggedIn }) {
  const [isLoading, setIsLoading] = useState(true);
  const [saveMovies, setSaveMovies] = useState([]); //сохраненные фильмы

  useEffect(() => {
    MainApi.getMovies()
      .then((res) => {
        setSaveMovies(res);
        localStorage.setItem("savedMovies", JSON.stringify(res));
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => setIsLoading(false));
  }, [setSaveMovies]);

  return (
    <>
      <Header loggedIn={!loggedIn} />
      <main className="main">
        <SearchForm
        // onSubmit={handleSubmit}
        // searchWord={searchWord}
        // setSearchWord={setSearchWord}
        // handleToggle={handleToggle}
        // isToggle={isToggle}
        />
        <MoviesCardList
          movies={saveMovies}
          isLoading={isLoading}
          // errorSearch={errorSearch}
        />
      </main>
      <Footer />
    </>
  );
}

export default SavedMovies;
