import React, { useEffect } from "react";
import { Navigate } from "react-router-dom";
import "./Login.css";
import AuthWithForm from "../AuthWithForm/AuthWithForm";
import useForm from "../../hooks/useForm";

function Login({ onLogin, loggedIn }) {
  const { values, handleChange, setValues } = useForm({
    email: "",
    password: "",
  });

  function handleSubmit(evt) {
    evt.preventDefault();
    onLogin(values);
  }

  useEffect(() => {
    setValues({ email: "", password: "" });
  }, [setValues]);

  if (loggedIn) {
    return <Navigate to="/movies" />;
  }
  return (
    <AuthWithForm
      nameForm="login"
      title="Рады видеть!"
      button="Войти"
      text="Ещё не зарегистрированы?"
      textLink="Регистрация"
      linkTo="/signup"
      onSubmit={handleSubmit}
    >
      <label className="auth__label">
        E-mail
        <input
          className="auth__input"
          type="email"
          name="email"
          placeholder="E-mail"
          required
          onChange={handleChange}
          value={values.email || ""}
        />
        <span className="auth__input-error email-error">
          Что-то пошло не так...
        </span>
      </label>

      <label className="auth__label">
        Пароль
        <input
          className="auth__input"
          type="password"
          name="password"
          placeholder="Пароль"
          minLength="4"
          maxLength="30"
          required
          onChange={handleChange}
          value={values.password || ""}
        />
        <span className="auth__input-error password-error">
          Что-то пошло не так...
        </span>
      </label>
    </AuthWithForm>
  );
}

export default Login;
