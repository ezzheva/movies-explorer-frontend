# Дипломная работа "Movies-explorer" frontend

Работа над frontend частью.

# _Ссылка на макет_

Макет я выбрала ligth-1
**[Ссылка на макет](https://www.figma.com/file/6FMWkB94wE7KTkcCgUXtnC/light-1?type=design&node-id=891-3857&mode=design&t=2o1n0jVrlmCiWxAF-0)**
